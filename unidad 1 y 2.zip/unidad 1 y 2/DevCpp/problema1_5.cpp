#include <iostream>
using namespace std;

int main()
{
    double RADIO, ALTU;
    double VOL, ARE;
    const double PI = 3.141592;

    cout << "Ingrese el radio del cilindro: ";
    cin >> RADIO;

    cout << "Ingrese la altura del cilindro: ";
    cin >> ALTU;

    VOL = PI * (RADIO * RADIO) * ALTU;
    ARE = 2.0 * PI * RADIO * ALTU;

    cout << "Volumen del cilindro:      " << VOL << endl;
    cout << "Area lateral del cilindro: " << ARE << endl;

    return 0;
}
