#include <iostream>
using namespace std;

int main()
{
    int DIAS;
    double SEG;

    cout << "Ingrese el numero de dias: ";
    cin >> DIAS;

    SEG = (double)DIAS * 24.0 * 60.0 * 60.0;

    cout << "En " << DIAS << " dias hay " << SEG << " segundos." << endl;

    return 0;
}
