#include <iostream>
#include <string>
using namespace std;

int main()
{
    string NOM;
    double PES, LON;
    double PESKIL, LONMET;

    cout << "Ingrese el nombre del dinosaurio: ";
    cin >> NOM;

    cout << "Ingrese el peso del dinosaurio en libras: ";
    cin >> PES;

    cout << "Ingrese la longitud del dinosaurio en pies: ";
    cin >> LON;

    PESKIL = PES * 1000.0;
    LONMET = LON * 0.3047;

    cout << "Nombre del dinosaurio: " << NOM    << endl;
    cout << "Peso en kilogramos:    " << PESKIL << " kg" << endl;
    cout << "Longitud en metros:    " << LONMET << " m"  << endl;

    return 0;
}
