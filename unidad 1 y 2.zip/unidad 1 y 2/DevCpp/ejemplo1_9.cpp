#include <iostream>
using namespace std;

int main()
{
    int NUM;
    double CUA, CUB;

    cout << "Ingrese un numero entero positivo: ";
    cin >> NUM;

    CUA = (double)NUM * NUM;
    CUB = (double)NUM * NUM * NUM;

    cout << "El cuadrado de " << NUM << " es: " << CUA << endl;
    cout << "El cubo de "     << NUM << " es: " << CUB << endl;

    return 0;
}
