#include <iostream>
using namespace std;

int main()
{
    double BASE, ALTU;
    double SUP, PER;

    cout << "Ingrese la base del rectangulo: ";
    cin >> BASE;

    cout << "Ingrese la altura del rectangulo: ";
    cin >> ALTU;

    SUP = BASE * ALTU;
    PER = 2.0 * (BASE + ALTU);

    cout << "Superficie del rectangulo: " << SUP << endl;
    cout << "Perimetro del rectangulo:  " << PER << endl;

    return 0;
}
