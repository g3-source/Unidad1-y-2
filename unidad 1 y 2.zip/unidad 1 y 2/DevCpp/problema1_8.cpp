#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double X1, Y1, X2, Y2;
    double DIS;

    cout << "Ingrese la coordenada X1 del punto P1: ";
    cin >> X1;

    cout << "Ingrese la coordenada Y1 del punto P1: ";
    cin >> Y1;

    cout << "Ingrese la coordenada X2 del punto P2: ";
    cin >> X2;

    cout << "Ingrese la coordenada Y2 del punto P2: ";
    cin >> Y2;

    DIS = pow((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2), 0.5);

    cout << "La distancia entre P1 y P2 es: " << DIS << endl;

    return 0;
}
