#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double L1, L2, L3;
    double S, AREA;

    cout << "Ingrese el lado L1: ";
    cin >> L1;

    cout << "Ingrese el lado L2: ";
    cin >> L2;

    cout << "Ingrese el lado L3: ";
    cin >> L3;

    S    = (L1 + L2 + L3) / 2.0;
    AREA = pow(S * (S - L1) * (S - L2) * (S - L3), 0.5);

    cout << "El area del triangulo es: " << AREA << endl;

    return 0;
}
