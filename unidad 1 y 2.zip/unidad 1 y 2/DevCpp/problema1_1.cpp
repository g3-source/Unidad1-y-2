#include <iostream>
using namespace std;

int main()
{
    double PREPRO, PAGO, DEVO;

    cout << "Ingrese el precio del producto: $";
    cin >> PREPRO;

    cout << "Ingrese el pago del cliente: $";
    cin >> PAGO;

    DEVO = PAGO - PREPRO;

    cout << "El cambio a entregar al cliente es: $" << DEVO << endl;

    return 0;
}
