#include <iostream>
using namespace std;

int main()
{
    int A, B, C, D;

    cout << "Por favor ingrese el primer valor A: ";
    cin >> A;

    cout << "Por favor ingrese el segundo valor B: ";
    cin >> B;

    cout << "Por favor ingrese el tercer valor C: ";
    cin >> C;

    cout << "Por favor ingrese el cuarto valor D: ";
    cin >> D;

    cout << "Los valores invertidos son: ";
    cout << D << " , " << C << " , " << B << " , " << A << endl;

    return 0;
}
