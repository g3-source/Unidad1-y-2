#include <iostream>
using namespace std;

int main()
{
    double GAL, TOTAL;

    cout << "Ingrese los galones de gasolina surtidos: ";
    cin >> GAL;

    TOTAL = GAL * 3.785 * 8.20;

    cout << "Total a cobrar al cliente: $" << TOTAL << endl;

    return 0;
}
